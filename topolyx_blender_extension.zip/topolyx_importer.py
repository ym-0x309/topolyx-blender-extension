"""Topolyx file pair importer core."""

from pathlib import Path
from typing import Callable, List, Optional, Sequence

import bpy
from mathutils import Vector

from .topolyx_attribute_import import apply_attributes
from .topolyx_binary import BinaryBufferReader
from .topolyx_coordinate import CoordinateConverter
from .topolyx_mesh_import import build_blender_mesh
from .topolyx_reader import read_topolyx
from .topolyx_types import TopolyxFile, Mesh, ObjectEntry
from .topolyx_utils import column_major_list_to_matrix


class TopolyxImportError(Exception):
    """Fatal error raised during Topolyx import."""

    pass


def import_topolyx(
    filepath: str | Path,
    import_attributes: bool = True,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> List[str]:
    """Import a Topolyx file pair into the current Blender scene.

    Args:
        filepath: Path to the .tlyx file.
        import_attributes: Whether to restore mesh attributes.
        progress_callback: Optional callback receiving (current_step, total_steps).

    Returns:
        List of warning messages collected during import.

    Raises:
        TopolyxImportError: If a fatal error occurs during import.
    """
    filepath = Path(filepath)

    try:
        topolyx_file, bin_data = read_topolyx(filepath)
    except Exception as exc:
        raise TopolyxImportError(f"Failed to read Topolyx file: {exc}") from exc

    converter = CoordinateConverter.from_coordinate_system(
        topolyx_file.coordinate_system
    )

    created_meshes: list[bpy.types.Mesh] = []
    created_objects: list[bpy.types.Object] = []
    warnings: list[str] = []

    total_steps = len(topolyx_file.meshes) + len(topolyx_file.objects)

    def _report_progress(current: int) -> None:
        if progress_callback is not None:
            progress_callback(current, total_steps)

    mesh_map: dict[int, bpy.types.Mesh] = {}

    try:
        for mesh_index, mesh_data in enumerate(topolyx_file.meshes):
            mesh = _build_mesh(
                mesh_data,
                bin_data,
                converter,
                import_attributes,
                warnings,
            )
            created_meshes.append(mesh)
            mesh_map[mesh_index] = mesh
            _report_progress(mesh_index + 1)

        for obj_index, obj_data in enumerate(topolyx_file.objects):
            obj = _create_object(
                obj_data,
                mesh_map[obj_data.index],
                converter,
            )
            created_objects.append(obj)
            _report_progress(len(topolyx_file.meshes) + obj_index + 1)

        _select_imported_objects(created_objects)
    except Exception as exc:
        _cleanup_import(created_objects, created_meshes)
        raise TopolyxImportError(f"Topolyx import failed: {exc}") from exc

    return warnings


def _build_mesh(
    mesh_data: Mesh,
    bin_data: bytes,
    converter: CoordinateConverter,
    import_attributes: bool,
    warnings: List[str],
) -> bpy.types.Mesh:
    """Build a Blender Mesh data block from a Topolyx mesh entry."""
    reader = BinaryBufferReader(bin_data)
    topo = mesh_data.topology

    positions = list(
        reader.read_f32(
            topo.positions.byte_offset,
            topo.positions.element_count * topo.positions.component_count,
        )
    )
    edges = list(
        reader.read_u32(
            topo.edges.byte_offset,
            topo.edges.element_count * topo.edges.component_count,
        )
    )
    corner_vertices = list(
        reader.read_u32(
            topo.corner_vertices.byte_offset,
            topo.corner_vertices.element_count
            * topo.corner_vertices.component_count,
        )
    )
    corner_edges = list(
        reader.read_u32(
            topo.corner_edges.byte_offset,
            topo.corner_edges.element_count * topo.corner_edges.component_count,
        )
    )
    face_offsets = list(
        reader.read_u32(
            topo.face_offsets.byte_offset,
            topo.face_offsets.element_count * topo.face_offsets.component_count,
        )
    )

    converted_positions = _convert_positions(positions, converter)

    mesh = build_blender_mesh(
        name=mesh_data.name or "ImportedMesh",
        positions=converted_positions,
        edges=edges,
        corner_vertices=corner_vertices,
        corner_edges=corner_edges,
        face_offsets=face_offsets,
        winding=converter.winding,
    )

    if import_attributes:
        attr_warnings = apply_attributes(
            mesh, mesh_data.attributes, bin_data, converter=converter
        )
        warnings.extend(attr_warnings)

    return mesh


def _convert_positions(
    positions: Sequence[float], converter: CoordinateConverter
) -> List[float]:
    """Convert a flat F32 position array from file space to Blender space."""
    converted: list[float] = []
    for i in range(0, len(positions), 3):
        v = converter.inverse_convert_position(
            Vector((positions[i], positions[i + 1], positions[i + 2]))
        )
        converted.extend((v.x, v.y, v.z))
    return converted


def _create_object(
    obj_data: ObjectEntry,
    source_mesh: bpy.types.Mesh,
    converter: CoordinateConverter,
) -> bpy.types.Object:
    """Create a Blender Object from a Topolyx object entry and link it to the scene."""
    obj = bpy.data.objects.new(obj_data.name or "ImportedObject", source_mesh)

    collection = bpy.context.view_layer.active_layer_collection.collection
    collection.objects.link(obj)

    blender_matrix = column_major_list_to_matrix(obj_data.transform)
    blender_matrix = converter.inverse_convert_matrix(blender_matrix)
    obj.matrix_world = blender_matrix

    return obj


def _select_imported_objects(objects: Sequence[bpy.types.Object]) -> None:
    """Select the imported objects and set the last one as active."""
    if not objects:
        return

    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = objects[-1]


def _cleanup_import(
    objects: Sequence[bpy.types.Object],
    meshes: Sequence[bpy.types.Mesh],
) -> None:
    """Remove objects and meshes created during a failed import."""
    for obj in objects:
        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)

    for mesh in meshes:
        if mesh.name in bpy.data.meshes:
            bpy.data.meshes.remove(mesh)
